package br.com.Carlos.Eduardo.pw3detran.detran;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Pw3DetranApplicationTests {

	@Test
	void contextLoads() {
	}

}
